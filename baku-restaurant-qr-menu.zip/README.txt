# HTML Export

This ZIP file contains the exported HTML content from your Hatch canvas.

## What's Inside:
- index.html: Your main HTML file. Open this to view your project.
- assets/: Your images and media files (29 images included)
  - assets/SmQiJ2JUg2kEmYXg6Rk7e.jpeg
  - assets/YX5S_BBRW2TTu0Qpvwu1Y.jpeg
  - assets/S2v0fpD6RyGa7Fjd55mfI.jpeg
  - assets/NSArAVydoOE9cj-ln5np5.jpeg
  - assets/nbUXgWP1bkJj0keMtnhOE.jpeg
  - assets/vihVmy_E0nL2nGHabzoac.jpeg
  - assets/zDnxAK0jjHR4V502R4H5t.jpeg
  - assets/EbeW-g4Po3ZMAZYIwhqAn.jpeg
  - assets/477GVKBaXerBVmrnOneNa.jpeg
  - assets/i9HC9_uj9Xwzyem5hLSZW.jpeg
  - assets/r4_nBrKZ7GHd9zxluGt2i.jpeg
  - assets/dB5F--9Tj8A7VJeD-eiEB.jpeg
  - assets/3zGj_7RuQQKW0J9C7Ols5.jpeg
  - assets/uO-4L-8rrtk5FdAmikJaP.jpeg
  - assets/nCgGzKI3MCppuB0A673zY.jpeg
  - assets/-dDfeH37bDLHZs5JugqyJ.jpeg
  - assets/Y99CyJPjHeM1LtU76AnHL.jpeg
  - assets/jR67GFxyWGnzhh5kYzbfD.jpeg
  - assets/GWL_ObBR9_8H54HZJTWEu.jpeg
  - assets/baklava_azerbaijani.jpeg
  - assets/ice_cream_assorted.jpeg
  - assets/walnut_murabba.jpeg
  - assets/azerbaijani_tea.jpeg
  - assets/turkish_coffee.jpeg
  - assets/espresso_coffee.jpeg
  - assets/ayran_drink.jpeg
  - assets/pomegranate_juice.jpeg
  - assets/orange_juice.jpeg
  - assets/homemade_lemonade.jpeg


## How to Use It:
1. Open index.html in a web browser. Use a local web server for best results.
2. Upload your files to a hosting service if you're planning to share them online.

## Sharing your Work
Share the entire contents of the ZIP file including the assets folder and its content to preserve images and formatting. Sharing just the index.html file will break the connection to your images.

Generated on: 11.08.2025, 06:30:45
